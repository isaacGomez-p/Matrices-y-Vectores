/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectormatriz;
import java.util.Scanner;
/**
 *
 * @author ISAACELEAZAR
 */
public class Vector implements OrientacionInterface{
        int a[];
        int i,tam;
        
        public static void cantidad(int _cant){
            System.out.println("Cantidad: "+_cant);
        }
        public void llenarVector(int _can){
            tam=_can;
            a=new int[_can];//asiganrle el tamaño
            Scanner b= new Scanner(System.in);
            System.out.println(""+a.length);
            for(i=0;i<_can;i++){
                System.out.println("Ingrese el numero"+(i+1));
                a[i]=b.nextInt();
            }
            for(i=0;i<a.length;i++){
                System.out.println("Posicion"+(i+1)+"-"+a[i]);
            }
            
        }
        @Override
    public void descendente(){
        for(int i=0;i<(a.length-1);i++){
            for(int j=i+1;j<a.length;j++){
                if(a[i]<a[j]){
                    //Intercambiamos valores
                    int variableauxiliar=a[i];
                    a[i]=a[j];
                    a[j]=variableauxiliar;
 
                }
            }
        }
        for(i=0;i<a.length;i++)
            System.out.print(+a[i]);
             
    }
        @Override
    public void ascendente(){
        
        for(int i=0;i<(a.length-1);i++){
            for(int j=i+1;j<a.length;j++){
                if(a[i]>a[j]){
                    //Intercambiamos valores
                    int variableauxiliar=a[i];
                    a[i]=a[j];
                    a[j]=variableauxiliar;
                 }
            }
        }
        for(i=0;i<a.length;i++)
            System.out.print(+a[i]);
    }
}
    
    
    
    
    

