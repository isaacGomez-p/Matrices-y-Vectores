/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectormatriz;
import java.util.Scanner;
/**
 *
 * @author ISAACELEAZAR
 */
public class Matriz implements OrientacionInterface{
     int a[][];
        int i,tam,j;
    public void llenarMatriz(int _can){
       
            tam=_can;
            a=new int[_can][_can];//asiganrle el tamaño
            Scanner b= new Scanner(System.in);
            System.out.println(""+a.length+"x"+a.length);
            for(i=0;i<_can;i++){
                for(j=0;j<_can;j++){
                System.out.println("Ingrese el numero "+(i+1)+"-"+(j+1));
                a[i][j]=b.nextInt();
                }
            }
            for(i=0;i<a.length;i++){
                for(j=0;j<_can;j++){
                System.out.print(a[i][j]+"  ");
                }
            System.out.println("  ");   
            }
            
        }
        @Override
    public void descendente(){
       	for( i=0; i <tam; i++){//ordena la matriz de abajo hacia arriba
            for(j=0;j<tam; j++){
		for(int x=0; x < tam; x++){
			for(int y=0; y<tam; y++){
			if(a[i][j] > a[x][y]){
			int aux = a[i][j];
			a[i][j] = a[x][y];
			a[x][y] = aux;
                        }
                    }
                }
            }
        }
    for ( i=0;i<a.length;i++){
	for( j=0;j<a.length;j++){
            System.out.print(a[i][j]+" ");
	}
        System.out.println("");
    }    
    
    }
        @Override
    public void ascendente(){
        	for( i=0; i <tam; i++){//ordena la matriz de abajo hacia arriba
            for(j=0;j<tam; j++){
		for(int x=0; x < tam; x++){
			for(int y=0; y<tam; y++){
			if(a[i][j] > a[x][y]){
			int aux = a[i][j];
			a[i][j] = a[x][y];
			a[x][y] = aux;
                        }
                    }
                }
            }
        } 
    for ( i=a.length-1;i>=0;i--){
	for( j=a.length-1;j>=0;j--){
            System.out.print(a[i][j]+"	");
	}
        System.out.println("");
    }
        
    }
}
