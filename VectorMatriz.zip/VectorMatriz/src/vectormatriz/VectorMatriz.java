/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectormatriz;
import java.util.Scanner;
/**
 *
 * @author ISAACELEAZAR
 */
public class VectorMatriz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int cant,ele,tip;
        Scanner el=new Scanner(System.in);
        Scanner ca=new Scanner(System.in);
        Scanner ti=new Scanner(System.in);
        
        System.out.println("1. Vector \n2. Matriz");
        ele= ca.nextInt();
        switch(ele){
            case 1:
                System.out.println("Digite la cantidad de posiciones: ");
                cant= ca.nextInt();
                //Vector.cantidad(cant);
                Vector obj1= new Vector();
                obj1.llenarVector(cant);
                System.out.println("Desea ordenarlo de manera: \n1. Descendente \n2. Ascendente");
                tip=ti.nextInt();
                switch(tip){
                    case 1:
                        obj1.descendente();
                        break;
                    case 2:
                        obj1.ascendente();
                        break;
                }
                break;
            case 2:
                System.out.println("Digite la cantidad de posiciones: ");
                cant= ca.nextInt();
                //Vector.cantidad(cant);
                Matriz obj2= new Matriz();
                obj2.llenarMatriz(cant);
                System.out.println("Desea ordenarlo de manera: \n1. Descendente \n2. Ascendente");
                tip=ti.nextInt();
                switch(tip){
                    case 1:
                        obj2.descendente();
                        break;
                    case 2:
                        obj2.ascendente();
                        break;
                    }
                break;
         }
        
    }
    
}
